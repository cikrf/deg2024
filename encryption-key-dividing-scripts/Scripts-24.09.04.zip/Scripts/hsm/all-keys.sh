/opt/cprocsp/bin/amd64/csptest -keys -enum -verifyc -provider "Crypto-Pro GOST R 34.10-2012 HSM CSP" -fqcn
