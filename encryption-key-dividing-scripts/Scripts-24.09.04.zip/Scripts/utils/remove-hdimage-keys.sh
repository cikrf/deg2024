rm /var/opt/cprocsp/keys/user/*.* -r
