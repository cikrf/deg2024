zip $CONT_NAME.zip $CONT_NAME.*
