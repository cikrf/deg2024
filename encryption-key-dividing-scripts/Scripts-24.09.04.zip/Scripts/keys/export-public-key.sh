/opt/cprocsp/bin/amd64/csptest -keyset -export $CONT_NAME.pub_key -provtype 80 -keytype exchange -container '\\.\EPHEMERICAL\'$CONT_NAME'div'
