export CONT_NAME=$1
echo $0
echo $CONT_NAME