/opt/cprocsp/bin/amd64/csptest -keycopy -typesrc 80 -typedest 80 -contsrc $CONT_NAME'div' -contdest '\\.\HDIMAGE\'$CONT_NAME -pindest "12345678"
