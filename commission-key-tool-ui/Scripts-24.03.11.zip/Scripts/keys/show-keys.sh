/opt/cprocsp/bin/amd64/csptest -keys -enum -verifyc -fqcn
