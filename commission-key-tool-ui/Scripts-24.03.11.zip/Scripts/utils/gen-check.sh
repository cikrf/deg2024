/opt/cprocsp/bin/amd64/csptest -keyset -verifyco -hard_rng
