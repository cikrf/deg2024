/opt/cprocsp/bin/amd64/csptest -keyset -deletekeyset -verifyco -pattern "" -provtype 80
