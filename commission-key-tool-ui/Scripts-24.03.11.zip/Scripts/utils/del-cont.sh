/opt/cprocsp/bin/amd64/csptest -keyset -deletekeyset -verifyco -pattern "div" -provtype 80
